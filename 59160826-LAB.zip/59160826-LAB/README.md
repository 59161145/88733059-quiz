# Vagrant Ansible LAB

For make LAB ansible

Install Oracle VirtualBox 6.0.4
  https://www.virtualbox.org/wiki/Downloads
  
Install vagrant 2.2.3
  https://www.vagrantup.com/downloads.html
  
Install vargrant plug-ins

`vagrant plugin install vagrant-vbguest`

`vagrant plugin install vagrant-hostmanager`
   
  

# How to use

`vagrant up`

`vagrant ssh ansible-mgn`
